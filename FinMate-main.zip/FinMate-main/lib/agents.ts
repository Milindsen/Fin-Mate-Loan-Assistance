import { fetchCreditScore, LOAN_OFFERS } from "./mockData";
import { User as UserType, LoanOffer, UnderwritingStatus } from "./types";
import User from "@/models/User";
import dbConnect from "@/lib/db";

// --- UTILITY: EMI CALCULATOR ---
function calculateEMI(principal: number, rate: number, months: number): number {
  const r = rate / 12 / 100;
  return Math.round(
    (principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1)
  );
}

// --- WORKER AGENT 1: VERIFICATION AGENT ---
export async function verificationAgent(phone: string) {
  await dbConnect();
  // Find user in MongoDB
  const user = await User.findOne({ phone });

  if (!user) {
    return {
      status: "FAILED" as const,
      message:
        "User not found in our records. Please visit a branch to register.",
    };
  }

  // Convert Mongoose document to plain object and map _id to id
  const userData = user.toObject();
  return {
    status: "SUCCESS" as const,
    data: { ...userData, id: userData._id.toString() } as UserType,
  };
}

// --- WORKER AGENT 2: UNDERWRITING AGENT ---
export async function underwritingAgent(
  user: UserType,
  requestedAmount: number,
  salarySlipUploaded: boolean = false
) {
  const creditScore = await fetchCreditScore(user.id);

  // Rule 1: Credit Score Check
  if (creditScore < 700) {
    return {
      status: UnderwritingStatus.REJECTED,
      reason: `Credit Score (${creditScore}) is below 700.`,
    };
  }

  // Rule 2: Absolute Limit Check (> 2x Pre-approved)
  const availableLimit = user.preApprovedLimit - (user.currentLoanAmount || 0);

  if (requestedAmount > 2 * availableLimit) {
    return {
      status: UnderwritingStatus.REJECTED,
      reason: `Amount exceeds 2x your available limit of ₹${availableLimit}.`,
    };
  }

  // Rule 3: Conditional Approval (Limit < Amount <= 2x Limit)
  if (requestedAmount > availableLimit && !salarySlipUploaded) {
    return {
      status: UnderwritingStatus.SALARY_SLIP_REQUIRED,
      reason: "Amount exceeds available limit. Please upload Salary Slip.",
    };
  }

  // Rule 4: EMI Check (if Salary Slip uploaded or just standard check)
  // Default tenure 36m for initial check
  const emi = calculateEMI(requestedAmount, LOAN_OFFERS.interestRate, 36);
  if (emi > 0.5 * user.salary) {
    return {
      status: UnderwritingStatus.REJECTED,
      reason: `EMI (₹${emi}) exceeds 50% of your monthly salary.`,
    };
  }

  const type =
    requestedAmount <= user.preApprovedLimit - (user.currentLoanAmount || 0)
      ? "INSTANT"
      : "SALARY_VERIFIED";

  return {
    status: UnderwritingStatus.APPROVED,
    details: {
      amount: requestedAmount,
      score: creditScore,
      type,
    },
  };
}

// --- WORKER AGENT 3: OFFER COMPOSITION AGENT ---
export async function offerCompositionAgent(
  amount: number
): Promise<LoanOffer[]> {
  const rate = LOAN_OFFERS.interestRate;
  const tenures = [12, 24, 36]; // Offer 3 options

  return tenures.map((months) => {
    const emi = calculateEMI(amount, rate, months);
    const totalPayment = emi * months;
    const totalInterest = totalPayment - amount;
    return {
      tenure: months,
      emi,
      rate,
      totalInterest,
    };
  });
}

// --- WORKER AGENT 4: EXPLAINABILITY AGENT ---
type ExplainabilityData = {
  amount?: number;
  score?: number;
  reason?: string;
};

export async function explainabilityAgent(status: string, data: ExplainabilityData) {
  if (status === "APPROVED") {
    return `We approved your loan of ₹${data.amount} because your Credit Score is ${data.score} (Excellent) and the EMI is within 50% of your salary.`;
  } else if (status === "REJECTED") {
    return `Your application was rejected because: ${data.reason}. We recommend improving your credit score or requesting a lower amount.`;
  }
  return "Processing your application...";
}
