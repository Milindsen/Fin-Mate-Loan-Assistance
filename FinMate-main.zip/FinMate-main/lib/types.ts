export interface User {
  id: string;
  phone: string;
  name: string;
  age?: number;
  city: string;
  salary: number;
  preApprovedLimit: number;
  kycStatus: string;
  pan?: string;
  aadhaar?: string;
  currentLoanAmount: number;
  creditHistory: {
    date: Date;
    amount: number;
    status: string;
    score: number;
    tenure?: number;
    emi?: number;
  }[];
}

export interface LoanOffer {
  tenure: number; // months
  emi: number;
  rate: number;
  totalInterest: number;
}

export interface LoanDetails {
  amount: number;
  emi: number;
  rate: number;
  score: number;
  type: string;
  tenure?: number;
}

export enum KYCStatus {
  VERIFIED = "VERIFIED",
  PENDING = "PENDING",
  FAILED = "FAILED",
}

export enum UnderwritingStatus {
  APPROVED = "APPROVED",
  REJECTED = "REJECTED",
  SALARY_SLIP_REQUIRED = "SALARY_SLIP_REQUIRED",
}

export interface Session {
  step:
    | "GREETING"
    | "KYC"
    | "PAN_COLLECTION"
    | "AADHAAR_COLLECTION"
    | "AMOUNT"
    | "UNDERWRITING"
    | "OFFER_SELECTION"
    | "CLOSURE";
  userData: User | null;
  decision?: LoanDetails;
  offers?: LoanOffer[];
  selectedOffer?: LoanOffer;
  explanation?: string;
  requestedAmount?: number;
}
