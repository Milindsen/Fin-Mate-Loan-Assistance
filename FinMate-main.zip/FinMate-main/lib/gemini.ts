import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = process.env.GEMINI_API_KEY;
const genAI = apiKey ? new GoogleGenerativeAI(apiKey) : null;

const model = genAI ? genAI.getGenerativeModel({ model: "gemini-2.5-flash" }) : null;

export async function classifyIntent(message: string): Promise<string> {
  if (!model) return "UNKNOWN";

  const prompt = `
    Classify the user's intent based on the message.
    Possible intents:
    - LOAN_APPLICATION: User wants a loan, needs money, or asks about loan eligibility.
    - INFO_PROVIDING: User is providing specific information like phone number, amount, or salary slip.
    - QUESTION: User is asking a general question about the service.
    - GREETING: User is saying hello.
    - CONFIRMATION: User is saying yes, agreeing, or selecting an option.
    
    Message: "${message}"
    
    Return ONLY the intent string.
  `;

  try {
    const result = await model.generateContent(prompt);
    const intent = result.response.text().trim();
    return intent;
  } catch (error) {
    console.error("Gemini Intent Error:", error);
    return "UNKNOWN";
  }
}

export async function generateSalesResponse(
  context: string,
  userMessage: string
): Promise<string> {
  if (!model) return "I am FinMate, here to help you with your loan.";

  const prompt = `
    You are FinMate, a friendly and professional AI loan sales assistant.
    Context: ${context}
    User Message: "${userMessage}"
    
    Generate a short, engaging response to the user. 
    If the context implies asking for information, be polite.
    If the context implies approval, be enthusiastic.
    Keep it under 50 words.
  `;

  try {
    const result = await model.generateContent(prompt);
    return result.response.text().trim();
  } catch (error) {
    console.error("Gemini Sales Error:", error);
    return "I am FinMate, here to help you with your loan.";
  }
}
