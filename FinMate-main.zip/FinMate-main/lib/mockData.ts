import { User } from "./types";

// 1. DUMMY CRM (Source: Verification Agent needs this)
export const MOCK_CRM: User[] = [
  {
    id: "cust_001",
    phone: "9876543210",
    name: "Arun Rathaur",
    age: 32,
    city: "Raipur",
    salary: 80000,
    preApprovedLimit: 500000,
    kycStatus: "VERIFIED",
    pan: "ABCDE1234F",
    aadhaar: "123456789012",
    currentLoanAmount: 250000,
    creditHistory: [
      {
        date: new Date("2024-06-15"),
        amount: 250000,
        status: "ACTIVE",
        score: 780,
        tenure: 36,
        emi: 8125
      }
    ]
  },
  {
    id: "cust_002",
    phone: "9988776655",
    name: "Naman Soni",
    age: 28,
    city: "Bhilai",
    salary: 45000,
    preApprovedLimit: 200000,
    kycStatus: "VERIFIED",
    pan: "FGHIJ5678K",
    aadhaar: "987654321098",
    currentLoanAmount: 150000,
    creditHistory: [
      {
        date: new Date("2024-09-10"),
        amount: 150000,
        status: "ACTIVE",
        score: 720,
        tenure: 24,
        emi: 7083
      }
    ]
  },
  {
    id: "cust_003",
    phone: "8269910123",
    name: "Priya Sharma",
    age: 35,
    city: "Mumbai",
    salary: 120000,
    preApprovedLimit: 800000,
    kycStatus: "VERIFIED",
    pan: "PQRST1234M",
    aadhaar: "234567890123",
    currentLoanAmount: 400000,
    creditHistory: [
      {
        date: new Date("2024-03-20"),
        amount: 400000,
        status: "ACTIVE",
        score: 810,
        tenure: 48,
        emi: 10167
      }
    ]
  },
  {
    id: "cust_004",
    phone: "7909905038",
    name: "Rajesh Kumar",
    age: 41,
    city: "Delhi",
    salary: 95000,
    preApprovedLimit: 600000,
    kycStatus: "VERIFIED",
    pan: "UVWXY5678D",
    aadhaar: "345678901234",
    currentLoanAmount: 0,
    creditHistory: [
      {
        date: new Date("2023-11-05"),
        amount: 300000,
        status: "CLOSED",
        score: 795,
        tenure: 24,
        emi: 14167
      }
    ]
  },
  {
    id: "cust_005",
    phone: "8434836451",
    name: "Anjali Desai",
    age: 29,
    city: "Bangalore",
    salary: 75000,
    preApprovedLimit: 450000,
    kycStatus: "VERIFIED",
    pan: "ZABCD9012B",
    aadhaar: "456789012345",
    currentLoanAmount: 200000,
    creditHistory: [
      {
        date: new Date("2024-07-22"),
        amount: 200000,
        status: "ACTIVE",
        score: 745,
        tenure: 36,
        emi: 6500
      }
    ]
  },
  {
    id: "cust_006",
    phone: "8079098396",
    name: "Vikram Singh",
    age: 38,
    city: "Jaipur",
    salary: 60000,
    preApprovedLimit: 350000,
    kycStatus: "VERIFIED",
    pan: "EFGHI3456J",
    aadhaar: "567890123456",
    currentLoanAmount: 175000,
    creditHistory: [
      {
        date: new Date("2024-08-15"),
        amount: 175000,
        status: "ACTIVE",
        score: 730,
        tenure: 30,
        emi: 6708
      }
    ]
  },
  {
    id: "cust_007",
    phone: "9123456789",
    name: "Meera Patel",
    age: 26,
    city: "Ahmedabad",
    salary: 55000,
    preApprovedLimit: 300000,
    kycStatus: "PENDING",
    pan: "JKLMN7890A",
    aadhaar: "678901234567",
    currentLoanAmount: 0,
    creditHistory: []
  },
  {
    id: "cust_008",
    phone: "9876501234",
    name: "Arjun Reddy",
    age: 33,
    city: "Hyderabad",
    salary: 110000,
    preApprovedLimit: 700000,
    kycStatus: "VERIFIED",
    pan: "OPQRS2345H",
    aadhaar: "789012345678",
    currentLoanAmount: 500000,
    creditHistory: [
      {
        date: new Date("2024-01-10"),
        amount: 500000,
        status: "ACTIVE",
        score: 825,
        tenure: 60,
        emi: 10833
      }
    ]
  },
  {
    id: "cust_009",
    phone: "8765432109",
    name: "Kavita Iyer",
    age: 31,
    city: "Chennai",
    salary: 85000,
    preApprovedLimit: 550000,
    kycStatus: "VERIFIED",
    pan: "TUVWX6789C",
    aadhaar: "890123456789",
    currentLoanAmount: 300000,
    creditHistory: [
      {
        date: new Date("2024-05-18"),
        amount: 300000,
        status: "ACTIVE",
        score: 765,
        tenure: 42,
        emi: 8571
      }
    ]
  },
  {
    id: "cust_010",
    phone: "7654321098",
    name: "Rohit Malhotra",
    age: 45,
    city: "Pune",
    salary: 150000,
    preApprovedLimit: 1000000,
    kycStatus: "VERIFIED",
    pan: "YZABC8901P",
    aadhaar: "901234567890",
    currentLoanAmount: 600000,
    creditHistory: [
      {
        date: new Date("2023-12-01"),
        amount: 600000,
        status: "ACTIVE",
        score: 850,
        tenure: 48,
        emi: 15250
      }
    ]
  },
];

// 2. MOCK CREDIT BUREAU API (Source: Underwriting Agent needs this)
export const fetchCreditScore = async (_userId: string): Promise<number> => {
  void _userId;
  // Simulating API latency
  await new Promise((resolve) => setTimeout(resolve, 500));
  // Returns a random score between 650 and 850
  return 750; // Hardcoded for success demo, or use: Math.floor(Math.random() * (850 - 650 + 1) + 650)
};

// 3. OFFER MART (Source: Sales Agent needs this)
export const LOAN_OFFERS = {
  interestRate: 11.5, // % p.a.
  tenureOptions: [12, 24, 36, 48, 60], // months
};
