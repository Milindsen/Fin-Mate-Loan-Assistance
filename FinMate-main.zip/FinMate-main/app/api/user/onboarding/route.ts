import { NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import User from "@/models/User";

function isMongoDuplicateKeyError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: unknown }).code === 11000
  );
}

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { clerkUserId, email, name, phone, city, salary, pan, aadhaar } = data;

    // Validate required fields
    if (!clerkUserId || !email || !name || !phone || !city || !salary || !pan || !aadhaar) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      );
    }

    // Validate PAN format
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    if (!panRegex.test(pan)) {
      return NextResponse.json(
        { error: "Invalid PAN format" },
        { status: 400 }
      );
    }

    // Validate Aadhaar format
    const aadhaarRegex = /^[0-9]{12}$/;
    if (!aadhaarRegex.test(aadhaar)) {
      return NextResponse.json(
        { error: "Invalid Aadhaar format" },
        { status: 400 }
      );
    }

    // Validate phone format
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(phone)) {
      return NextResponse.json(
        { error: "Invalid phone format" },
        { status: 400 }
      );
    }

    await dbConnect();

    // Check if user already exists
    const existingUser = await User.findOne({ clerkUserId });
    if (existingUser) {
      return NextResponse.json(
        { error: "User already exists" },
        { status: 400 }
      );
    }

    // Calculate pre-approved limit based on salary (3x monthly salary)
    const preApprovedLimit = salary * 3;

    // Create new user
    const newUser = await User.create({
      clerkUserId,
      email,
      name,
      phone,
      city,
      salary,
      pan,
      aadhaar,
      preApprovedLimit,
      kycStatus: "VERIFIED",
      currentLoanAmount: 0,
      creditHistory: [],
    });

    return NextResponse.json(
      { message: "User created successfully", user: newUser },
      { status: 201 }
    );
  } catch (error: unknown) {
    console.error("Onboarding error:", error);

    if (isMongoDuplicateKeyError(error)) {
      return NextResponse.json(
        { error: "Phone, email, or PAN already registered" },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: "Failed to create user" },
      { status: 500 }
    );
  }
}
