import { NextResponse } from "next/server";
import { currentUser } from "@clerk/nextjs/server";
import dbConnect from "@/lib/db";
import User from "@/models/User";

export async function GET() {
  try {
    const user = await currentUser();
    
    if (!user) {
      return NextResponse.json(
        { completed: false, message: "Not authenticated" },
        { status: 401 }
      );
    }

    await dbConnect();
    const dbUser = await User.findOne({ clerkUserId: user.id });

    if (!dbUser) {
      return NextResponse.json({ completed: false }, { status: 200 });
    }

    // Check if all required fields are filled
    const isComplete = !!(
      dbUser.phone &&
      dbUser.city &&
      dbUser.salary &&
      dbUser.pan &&
      dbUser.aadhaar
    );

    return NextResponse.json({ completed: isComplete, user: dbUser }, { status: 200 });
  } catch (error) {
    console.error("Error checking onboarding status:", error);
    return NextResponse.json(
      { completed: false, message: "Error checking status" },
      { status: 500 }
    );
  }
}
