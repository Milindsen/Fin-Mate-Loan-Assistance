// app/api/chat/route.ts
import { NextResponse } from "next/server";
import {
  verificationAgent,
  underwritingAgent,
  offerCompositionAgent,
  explainabilityAgent,
} from "@/lib/agents";
import { Session, UnderwritingStatus } from "@/lib/types";
import { classifyIntent, generateSalesResponse } from "@/lib/gemini";
import dbConnect from "@/lib/db";
import User from "@/models/User";

// In-memory session state (Note: In production, use Redis/Database)
let session: Session = {
  step: "GREETING",
  userData: null,
};

export async function POST(req: Request) {
  const { message } = await req.json();

  try {
    // Determine Intent using Gemini
    const intent = await classifyIntent(message);
    console.log(`User Intent: ${intent} | Step: ${session.step}`);

    // --- STEP 1: GREETING & INTENT ---
    if (session.step === "GREETING") {
      if (
        intent === "LOAN_APPLICATION" ||
        message.toLowerCase().includes("loan")
      ) {
        session.step = "KYC";
        const response = await generateSalesResponse(
          "User wants a loan. Ask for their phone number to check eligibility.",
          message
        );
        return NextResponse.json({ role: "assistant", content: response });
      }

      const greeting = await generateSalesResponse(
        "User is greeting. Welcome them to FinMate.",
        message
      );
      return NextResponse.json({ role: "assistant", content: greeting });
    }

    // --- STEP 2: VERIFICATION (PHONE) ---
    if (session.step === "KYC") {
      const phoneMatch = message.match(/\d{10}/);
      if (!phoneMatch) {
        return NextResponse.json({
          role: "assistant",
          content: "Could you please provide a valid 10-digit phone number?",
        });
      }

      const kycResult = await verificationAgent(phoneMatch[0]);

      if (kycResult.status === "SUCCESS") {
        session.userData = kycResult.data;
        session.step = "PAN_COLLECTION"; // Move to PAN collection

        return NextResponse.json({
          role: "assistant",
          content: `Welcome back, ${session.userData.name}! Verified. \n\nTo proceed, please enter your PAN Number.`,
        });
      } else {
        return NextResponse.json({
          role: "assistant",
          content: kycResult.message,
        });
      }
    }

    // --- STEP 2.1: PAN COLLECTION ---
    if (session.step === "PAN_COLLECTION") {
      const panRegex = /[A-Z]{5}[0-9]{4}[A-Z]{1}/;
      const panMatch = message.toUpperCase().match(panRegex);

      if (!panMatch) {
        return NextResponse.json({
          role: "assistant",
          content: "Please enter a valid PAN Number (e.g., ABCDE1234F).",
        });
      }

      // Update PAN in DB
      await dbConnect();
      await User.findByIdAndUpdate(session.userData!.id, { pan: panMatch[0] });
      session.userData!.pan = panMatch[0];

      session.step = "AADHAAR_COLLECTION";
      return NextResponse.json({
        role: "assistant",
        content: "PAN verified. \n\nPlease enter your 12-digit Aadhaar Number.",
      });
    }

    // --- STEP 2.2: AADHAAR COLLECTION ---
    if (session.step === "AADHAAR_COLLECTION") {
      const aadhaarMatch = message.match(/\d{12}/);

      if (!aadhaarMatch) {
        return NextResponse.json({
          role: "assistant",
          content: "Please enter a valid 12-digit Aadhaar Number.",
        });
      }

      // Update Aadhaar in DB
      await dbConnect();
      await User.findByIdAndUpdate(session.userData!.id, {
        aadhaar: aadhaarMatch[0],
      });
      session.userData!.aadhaar = aadhaarMatch[0];

      session.step = "AMOUNT";
      return NextResponse.json({
        role: "assistant",
        content: `KYC Complete! Your pre-approved limit is ₹${
          session.userData!.preApprovedLimit
        }. \n\nHow much loan amount do you need?`,
      });
    }

    // --- STEP 3: SALES & UNDERWRITING ---
    if (session.step === "AMOUNT") {
      const amount = parseInt(message.replace(/[^0-9]/g, ""));
      if (!amount) {
        return NextResponse.json({
          role: "assistant",
          content: "Please specify the amount you need in numbers.",
        });
      }

      session.requestedAmount = amount;

      // Initial Underwriting Check
      const decision = await underwritingAgent(session.userData!, amount);

      if (decision.status === UnderwritingStatus.SALARY_SLIP_REQUIRED) {
        session.step = "UNDERWRITING";
        return NextResponse.json({
          role: "assistant",
          content: `Your request for ₹${amount} is higher than your available limit. Could you please upload your latest Salary Slip? (Type "Uploaded" to simulate)`,
        });
      }

      if (decision.status === UnderwritingStatus.REJECTED) {
        const explanation = await explainabilityAgent("REJECTED", decision);
        session.step = "GREETING"; // Reset
        return NextResponse.json({
          role: "assistant",
          content: explanation,
        });
      }

      // If Approved Instantly
      if (decision.status === UnderwritingStatus.APPROVED) {
        const offers = await offerCompositionAgent(amount);
        session.offers = offers;
        session.step = "OFFER_SELECTION";

        const offerText = offers
          .map(
            (o, i) =>
              `${i + 1}. ${o.tenure} Months - EMI: ₹${o.emi} @ ${o.rate}%`
          )
          .join("\n");

        return NextResponse.json({
          role: "assistant",
          content: `Great news! You are eligible. Here are your options:\n\n${offerText}\n\nPlease reply with the option number (e.g., "1").`,
        });
      }
    }

    // --- STEP 3.5: SALARY SLIP CHECK ---
    if (session.step === "UNDERWRITING") {
      if (
        message.toLowerCase().includes("upload") ||
        intent === "INFO_PROVIDING"
      ) {
        const decision = await underwritingAgent(
          session.userData!,
          session.requestedAmount!,
          true
        );

        if (decision.status === UnderwritingStatus.APPROVED) {
          const offers = await offerCompositionAgent(session.requestedAmount!);
          session.offers = offers;
          session.step = "OFFER_SELECTION";

          const offerText = offers
            .map(
              (o, i) =>
                `${i + 1}. ${o.tenure} Months - EMI: ₹${o.emi} @ ${o.rate}%`
            )
            .join("\n");

          return NextResponse.json({
            role: "assistant",
            content: `Salary Slip verified! Here are your loan options:\n\n${offerText}\n\nPlease select an option.`,
          });
        } else {
          const explanation = await explainabilityAgent("REJECTED", decision);
          session.step = "GREETING";
          return NextResponse.json({
            role: "assistant",
            content: explanation,
          });
        }
      }
      return NextResponse.json({
        role: "assistant",
        content: "Please type 'Uploaded' to simulate uploading your documents.",
      });
    }

    // --- STEP 4: OFFER SELECTION ---
    if (session.step === "OFFER_SELECTION") {
      const selection = parseInt(message.replace(/[^0-9]/g, ""));
      if (selection > 0 && selection <= (session.offers?.length || 0)) {
        session.selectedOffer = session.offers![selection - 1];
        session.step = "CLOSURE";

        const explanation = await explainabilityAgent("APPROVED", {
          amount: session.requestedAmount,
          score: 750,
        });

        return NextResponse.json({
          role: "assistant",
          content: `You selected: ${session.selectedOffer.tenure} Months tenure.\n\n${explanation}\n\nType 'Yes' to confirm and generate your Sanction Letter.`,
        });
      }
      return NextResponse.json({
        role: "assistant",
        content: "Please select a valid option number.",
      });
    }

    // --- STEP 5: CLOSURE & SANCTION LETTER ---
    if (session.step === "CLOSURE") {
      if (message.toLowerCase().includes("yes") || intent === "CONFIRMATION") {
        const finalDetails = {
          amount: session.requestedAmount!,
          emi: session.selectedOffer!.emi,
          rate: session.selectedOffer!.rate,
          tenure: session.selectedOffer!.tenure,
          name: session.userData!.name,
          score: 750,
        };

        // UPDATE DB: Add to Credit History & Update Current Loan
        await dbConnect();
        await User.findByIdAndUpdate(session.userData!.id, {
          $inc: { currentLoanAmount: session.requestedAmount },
          $push: {
            creditHistory: {
              amount: session.requestedAmount,
              status: "ACTIVE",
              score: 750,
              date: new Date(),
            },
          },
        });

        session = { step: "GREETING", userData: null };

        return NextResponse.json({
          role: "assistant",
          content:
            "Congratulations! Your Sanction Letter is ready. Downloading now...",
          action: "DOWNLOAD_PDF",
          payload: finalDetails,
        });
      }
    }

    // Fallback for unhandled states
    const fallback = await generateSalesResponse(
      "User said something unclear. Ask them to clarify.",
      message
    );
    return NextResponse.json({ role: "assistant", content: fallback });
  } catch (error) {
    console.error(error);
    return NextResponse.json({
      role: "assistant",
      content:
        "I'm having trouble connecting right now. Please try again later.",
    });
  }
}
