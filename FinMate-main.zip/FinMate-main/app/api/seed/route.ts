import { NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import User from "@/models/User";
import { MOCK_CRM } from "@/lib/mockData";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await dbConnect();

    // Clear existing users to avoid duplicates
    await User.deleteMany({});

    // Transform MOCK_CRM data to match User model schema
    const usersToInsert = MOCK_CRM.map((user, index) => ({
      clerkUserId: user.id,
      email: `user${index + 1}@finmate.com`,
      phone: user.phone,
      name: user.name,
      age: user.age,
      city: user.city,
      salary: user.salary,
      preApprovedLimit: user.preApprovedLimit,
      kycStatus: user.kycStatus,
      pan: user.pan,
      aadhaar: user.aadhaar,
      currentLoanAmount: user.currentLoanAmount,
      creditHistory: user.creditHistory.map(history => ({
        date: history.date,
        amount: history.amount,
        status: history.status,
        score: history.score,
        tenure: history.tenure,
        emi: history.emi,
      })),
    }));

    // Insert mock data
    await User.insertMany(usersToInsert);

    return NextResponse.json({
      message: "Database seeded successfully with 10 users",
      count: usersToInsert.length,
      users: usersToInsert.map(u => ({
        name: u.name,
        phone: u.phone,
        city: u.city,
        preApprovedLimit: u.preApprovedLimit,
        currentLoanAmount: u.currentLoanAmount,
      })),
    });
  } catch (error) {
    console.error("Seeding error:", error);
    return NextResponse.json(
      { error: "Failed to seed database", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
