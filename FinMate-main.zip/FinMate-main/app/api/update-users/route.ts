import { NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import User from "@/models/User";
import { MOCK_CRM } from "@/lib/mockData";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await dbConnect();

    let updatedCount = 0;
    let createdCount = 0;

    // Update or create each user from MOCK_CRM
    for (const mockUser of MOCK_CRM) {
      const existingUser = await User.findOne({ phone: mockUser.phone });

      if (existingUser) {
        // Update existing user with new fields
        await User.findOneAndUpdate(
          { phone: mockUser.phone },
          {
            $set: {
              name: mockUser.name,
              city: mockUser.city,
              salary: mockUser.salary,
              preApprovedLimit: mockUser.preApprovedLimit,
              kycStatus: mockUser.kycStatus,
              pan: mockUser.pan,
              aadhaar: mockUser.aadhaar,
              // Only set these if they don't exist
              ...(existingUser.currentLoanAmount === undefined && {
                currentLoanAmount: 0,
              }),
              ...(existingUser.creditHistory === undefined && {
                creditHistory: [],
              }),
            },
          }
        );
        updatedCount++;
      } else {
        // Create new user
        await User.create(mockUser);
        createdCount++;
      }
    }

    return NextResponse.json({
      message: "Database updated successfully",
      updated: updatedCount,
      created: createdCount,
      total: MOCK_CRM.length,
    });
  } catch (error) {
    console.error("Update error:", error);
    return NextResponse.json(
      { error: "Failed to update database", details: error },
      { status: 500 }
    );
  }
}
