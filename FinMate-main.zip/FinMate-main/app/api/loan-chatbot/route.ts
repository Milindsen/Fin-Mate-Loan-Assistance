import { NextRequest, NextResponse } from "next/server";

const SESSION_COOKIE = "loan_chatbot_session";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const message = typeof body?.message === "string" ? body.message : "";

  if (!message.trim()) {
    return NextResponse.json(
      { role: "assistant", content: "Please enter a message." },
      { status: 400 }
    );
  }

  const baseUrl = process.env.LOAN_CHATBOT_BASE_URL;

  if (!baseUrl) {
    return NextResponse.json(
      {
        role: "assistant",
        content:
          "Server misconfigured: LOAN_CHATBOT_BASE_URL is not set. Please configure it in .env.",
      },
      { status: 500 }
    );
  }
  const existingSessionId = req.cookies.get(SESSION_COOKIE)?.value;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);

  try {
    const upstreamRes = await fetch(`${baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, sessionId: existingSessionId }),
      signal: controller.signal,
    });

    if (!upstreamRes.ok) {
      const text = await upstreamRes.text().catch(() => "");
      return NextResponse.json(
        {
          role: "assistant",
          content: `Loan chatbot service error (${upstreamRes.status}). ${text}`.trim(),
        },
        { status: 502 }
      );
    }

    const data = (await upstreamRes.json()) as {
      sessionId?: string;
      message?: string;
      meta?: { action?: string; payload?: unknown };
    };

    const res = NextResponse.json({
      role: "assistant",
      content: data?.message ?? "",
      action: data?.meta?.action,
      payload: data?.meta?.payload,
    });

    if (data?.sessionId && data.sessionId !== existingSessionId) {
      res.cookies.set(SESSION_COOKIE, data.sessionId, {
        path: "/",
        httpOnly: true,
        sameSite: "lax",
      });
    }

    return res;
  } catch (error: unknown) {
    const isAbort =
      typeof error === "object" &&
      error !== null &&
      "name" in error &&
      (error as { name?: unknown }).name === "AbortError";
    return NextResponse.json(
      {
        role: "assistant",
        content: isAbort
          ? "Loan chatbot service timed out. Please try again."
          : "Loan chatbot service is unreachable. Is the Python server running?",
      },
      { status: 502 }
    );
  } finally {
    clearTimeout(timeout);
  }
}
