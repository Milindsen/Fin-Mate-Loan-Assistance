import mongoose, { Schema, Document, Model } from "mongoose";

export interface IApplication extends Document {
  userId: mongoose.Types.ObjectId;
  amount: number;
  status: string;
  offerSelected?: {
    tenure: number;
    emi: number;
    rate: number;
  };
  createdAt: Date;
}

const ApplicationSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  amount: { type: Number, required: true },
  status: { type: String, required: true },
  offerSelected: {
    tenure: Number,
    emi: Number,
    rate: Number,
  },
  createdAt: { type: Date, default: Date.now },
});

const Application: Model<IApplication> =
  mongoose.models.Application ||
  mongoose.model<IApplication>("Application", ApplicationSchema);

export default Application;
