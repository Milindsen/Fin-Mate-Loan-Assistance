import mongoose, { Schema, Document, Model } from "mongoose";

export interface IUser extends Document {
  clerkUserId: string;
  email: string;
  phone: string;
  name: string;
  age?: number;
  city: string;
  salary: number;
  preApprovedLimit: number;
  kycStatus: string;
  pan?: string;
  aadhaar?: string;
  currentLoanAmount: number;
  creditHistory: {
    date: Date;
    amount: number;
    status: string;
    score: number;
    tenure?: number;
    emi?: number;
  }[];
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema: Schema = new Schema({
  clerkUserId: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  age: { type: Number },
  city: { type: String, required: true },
  salary: { type: Number, required: true },
  preApprovedLimit: { type: Number, required: true },
  kycStatus: { type: String, required: true, default: "PENDING" },
  pan: { type: String },
  aadhaar: { type: String },
  currentLoanAmount: { type: Number, default: 0 },
  creditHistory: [
    {
      date: { type: Date, default: Date.now },
      amount: Number,
      status: String,
      score: Number,
      tenure: Number,
      emi: Number,
    },
  ],
}, { timestamps: true });

// Prevent overwrite during hot reload
const User: Model<IUser> =
  mongoose.models.User || mongoose.model<IUser>("User", UserSchema);

export default User;
