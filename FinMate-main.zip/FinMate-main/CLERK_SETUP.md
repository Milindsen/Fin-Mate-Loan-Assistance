# Clerk Authentication Setup Guide

## 1. Get Clerk API Keys

1. Go to [Clerk Dashboard](https://dashboard.clerk.com/)
2. Sign up or log in
3. Create a new application or select existing one
4. Go to **API Keys** section
5. Copy:
   - **Publishable Key** → `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`
   - **Secret Key** → `CLERK_SECRET_KEY`

## 2. Update .env.local

Replace the placeholder values in `.env.local`:

```env
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_your_key_here
CLERK_SECRET_KEY=sk_test_your_key_here
CLERK_WEBHOOK_SECRET=whsec_your_webhook_secret_here
```

## 3. Configure Clerk Webhook (Important!)

1. In Clerk Dashboard, go to **Webhooks**
2. Click **Add Endpoint**
3. Set Endpoint URL: `https://your-domain.com/api/webhooks/clerk`
   - For development: `http://localhost:3000/api/webhooks/clerk`
   - Use ngrok for local testing: `https://your-ngrok-url.ngrok.io/api/webhooks/clerk`
4. Subscribe to events:
   - ✅ `user.created`
   - ✅ `user.deleted`
5. Copy the **Signing Secret** → `CLERK_WEBHOOK_SECRET` in `.env.local`

## 4. User Flow

### Sign Up Process:
1. User visits `/sign-up`
2. Creates account with email/password (Clerk handles this)
3. After signup, redirected to `/onboarding`
4. User fills in:
   - Phone Number (10 digits)
   - City
   - Monthly Salary
   - PAN Number (format: ABCDE1234F)
   - Aadhaar Number (12 digits)
5. System calculates pre-approved loan limit (3x monthly salary)
6. User data saved to MongoDB
7. Redirected to `/dashboard`

### Sign In Process:
1. User visits `/sign-in`
2. Enters credentials
3. Redirected to `/dashboard`

## 5. Protected Routes

The following routes require authentication:
- `/dashboard` - View loan applications and analytics
- `/chat` - AI loan assistant
- `/onboarding` - Complete profile setup

Public routes:
- `/` - Home page
- `/sign-in` - Login page
- `/sign-up` - Registration page

## 6. MongoDB Integration

User data structure:
```typescript
{
  clerkUserId: string,     // Links to Clerk user
  email: string,
  phone: string,
  name: string,
  city: string,
  salary: number,
  preApprovedLimit: number, // Calculated as 3x salary
  kycStatus: string,        // VERIFIED by default
  pan: string,
  aadhaar: string,
  currentLoanAmount: number,
  creditHistory: []
}
```

## 7. Testing Locally

1. Update `.env.local` with your Clerk keys
2. Run: `npm run dev`
3. Visit: `http://localhost:3000`
4. Click "Sign Up" in sidebar
5. Complete registration and onboarding

## 8. Webhook Testing (Development)

Use ngrok to expose localhost:
```bash
ngrok http 3000
```

Then use the ngrok URL in Clerk webhook settings.

## Features Implemented

✅ Clerk authentication (email/password + social login)
✅ Custom onboarding with KYC fields (PAN, Aadhaar, Phone)
✅ MongoDB user data storage
✅ Webhook sync for user creation/deletion
✅ Protected routes with middleware
✅ User profile in sidebar
✅ Sign out functionality
✅ Pre-approved loan limit calculation

## Next Steps

- Add profile edit page
- Add KYC verification logic
- Integrate with loan application flow
- Add admin dashboard for user management
